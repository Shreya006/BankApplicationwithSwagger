package com.fis.bankapplication;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.model.Transaction;
import com.fis.bankapplication.service.AccountService;
import com.fis.bankapplication.service.CustomerService;
import com.fis.bankapplication.service.TransactionService;

@SpringBootTest
class TransactionTests {

    @Autowired
    TransactionService transactionService;
    
    @Autowired
    AccountService accountService;
    
	@Autowired
	CustomerService customerService;

    @Test
    public void testAddTransaction() {
    	
    	Customer customer = new Customer(1, "Shreya", "9870578171", "s@gmail.com", "333344445555", new Date(), "Pune",
				"New Delhi", "SE1");    	
		customerService.addCustomer(customer);
		
		Account account = new Account(1, customer, "Savings", "Bengaluru", new Date(), "Shreya123", 1000.0);
		accountService.addAccount(account);
    	
    	
        Transaction transaction = new Transaction(1, account, account, 500.0, new Date(), "Deposit");
        String result = transactionService.addTransaction(transaction);
        assertEquals("Transaction added Successfully", result);
    }

    @Test
    public void testUpdateTransaction() {
    	
    	Customer customer = new Customer(1, "Shreya", "9870578171", "s@gmail.com", "333344445555", new Date(), "Pune",
				"New Delhi", "SE1");    	
		customerService.addCustomer(customer);
		
		Account account = new Account(1, customer, "Savings", "Bengaluru", new Date(), "Shreya123", 1000.0);
		accountService.addAccount(account);
		
        Transaction transaction = new Transaction(2, account, account, 500.0, new Date(), "Deposit");

        transactionService.addTransaction(transaction);

        transaction.setAmount(1500);
        
        String result = transactionService.updateTransaction(transaction);

        assertEquals("Transaction updated Successfully", result);
    }

    @Test
    public void testDeleteTransaction() {
    	Customer customer = new Customer(1, "Shreya", "9870578171", "s@gmail.com", "333344445555", new Date(), "Pune",
				"New Delhi", "SE1");    	
		customerService.addCustomer(customer);
		
		Account account = new Account(1, customer, "Savings", "Bengaluru", new Date(), "Shreya123", 1000.0);
		accountService.addAccount(account);
		
        Transaction transaction = new Transaction(3, account, account, 500.0, new Date(), "Wrong Transfer");
        transactionService.addTransaction(transaction);
        
        String result = transactionService.deleteTransaction(transaction.getId());

        assertEquals("Transaction deleted Successfully", result);
    }

    @Test
    public void testGetTransactionById() {
    	Customer customer = new Customer(1, "Shreya", "9870578171", "s@gmail.com", "333344445555", new Date(), "Pune",
				"New Delhi", "SE1");    	
		customerService.addCustomer(customer);
		
		Account account = new Account(1, customer, "Savings", "Bengaluru", new Date(), "Shreya123", 1000.0);
		accountService.addAccount(account);
		
        Transaction expectedTransaction = new Transaction(1, account, account, 2500, new Date(), "Deposit");
        
        transactionService.addTransaction(expectedTransaction);
        Transaction actualTransaction = transactionService.getTransactionById(1);

        assertNotNull(actualTransaction);
        assertEquals(expectedTransaction.getId(), actualTransaction.getId());
    }

    @Test
    public void testGetAllTransactions() {
    	Customer customer = new Customer(1, "Shreya", "9870578171", "s@gmail.com", "333344445555", new Date(), "Pune",
				"New Delhi", "SE1");    	
		customerService.addCustomer(customer);
		
		Account account = new Account(1, customer, "Savings", "Bengaluru", new Date(), "Shreya123", 1000.0);
		accountService.addAccount(account);
		
        Transaction transaction1 = new Transaction(1, account, account, 500, new Date(), "Deposit");
        Transaction transaction2 = new Transaction(2, account, account, 500, new Date(), "Withdraw");

        transactionService.addTransaction(transaction1);
        transactionService.addTransaction(transaction2);
        
        List<Transaction> actualTransactions = transactionService.getAllTransactions();

        assertEquals(2, actualTransactions.size());
    }

}